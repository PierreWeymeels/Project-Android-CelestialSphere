package weymeelspierre.starstracker.renderOpenGl;

/**
 * Created by Pierre on 3/02/2015.
 */
public enum Render {

  GridRA_DE_render,GeoElementsRender,ConstellationRender,NamesRender,
  StarsRender,SolarSystemBodyRender
}
